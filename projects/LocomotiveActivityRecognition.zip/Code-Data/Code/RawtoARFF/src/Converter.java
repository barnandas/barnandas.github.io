import java.io.*;
import java.util.LinkedList;
import javax.media.j3d.Transform3D;
import javax.vecmath.Vector3d;
import javax.vecmath.Vector3f;

public class Converter {

	/**
	 * The length of time to group data samples for feature extraction
	 */
	private static long WINDOW = 4000;
	/**
	 * The amount of time to shift the window of data samples
	 */
	private static long WINDOWSHIFT = 2000;
	/**
	 * The length of time to remove junk samples at the beginning and end of a
	 * data stream
	 */
	private static long JUNKTIME = 2000;

	/**
	 * 
	 * @param args
	 *            A single string providing the path to the folder containing
	 *            the raw data
	 */
	public static void main(String[] args) {
		LinkedList<ARFFSample> ARFFs = new LinkedList<ARFFSample>();
		BufferedReader in;
		String[] folders = {"arya","brisa","emma","garrett","john","patrick","sadiq","sean","stefan","victor"};
		String[] activities = {"Biking", "Climbing", "Driving", "Lying",	"Not-on-Person", "Running", "Sitting", "Standing", "Walking"};//,"CleaningKitchen", "Cooking", "Medication", "Sweeping", "WashingHands", "WateringPlants"};
		for (String folder : folders)
		{
		for (String activity : activities) {
			//Open the activity file
			try {
				in = new BufferedReader(new FileReader(args[0] + folder + "\\" + activity
						+ ".raw"));
			} catch (Exception e) {
				continue;
			}

			LinkedList<Sample> data = new LinkedList<Sample>();
			// Processes the data stream until the end is reach or an exception
			// is thrown
			while (RemoveJunk(in)) {

				// Seeds the data list with the first sample
				// necessary for the CollectSamples methods
				try {
					data.add(Sample.Parse(in.readLine()));
				} catch (IOException e) {
					break;
				}

				// Continually collects and evaluates samples until
				// the end of a sample set
				while (CollectSamples(data, in)) {
					if (data.size() != 0)
						ARFFs.add(CreateARFFSample(data,activity));
					// Do stuff with the samples in here
					ShiftWindow(data);
				}
			}
		}
		}
		PrintARFF(ARFFs,args[0]);
		return;
	}

	/**
	 * Removes the junk from the beginning of a stream of sample data.
	 * 
	 * @param in
	 *            The stream of sample data.
	 * @return True if samples are ready to be processed. False if the end of
	 *         the file has been reached or another exception is thrown.
	 */
	private static boolean RemoveJunk(BufferedReader in) {
		try {
			// Get through trash data at the beginning of the file
			in.readLine();
			in.readLine();

			// Get starting time of data collection
			String string = in.readLine();
			if (string == null)
				return false;
			long startTime = Long.parseLong(string.split(" ")[0]);

			// Reads in the JUNKTIME to improve accuracy
			long currentTime;
			do {
				String s = in.readLine();
				currentTime = Long.parseLong(s.split(" ")[0]);
			} while (currentTime - startTime < JUNKTIME);

			// Reads any null values that might still be in the data set
			while ((Sample.Parse(in.readLine())) == null)
				;
		} catch (Exception e) {
			return false;
		}
		return true;
	}

	/**
	 * Collects WINDOW milliseconds of samples for evaluation.
	 * 
	 * @param data
	 *            Collection to store samples, must have at least one sample in
	 *            it.
	 * @param in
	 *            Stream to read sample data from.
	 * @return Returns true if a set of samples was successfully collected into
	 *         data. Returns false if the end of a data set was reached or
	 *         another exception was thrown.
	 */
	public static boolean CollectSamples(LinkedList<Sample> data,
			BufferedReader in) {
		try {
			// Reads in WINDOW milliseconds worth of data samples
			// sample will be null when the end of a data stream is reached
			Sample sample;
			for (sample = Sample.Parse(in.readLine()); sample != null
					&& sample.time - data.element().time < WINDOW; sample = Sample
					.Parse(in.readLine())) {
				data.add(NormalizeAcceleration(sample));
			}

			if (sample == null)
				return false;

		} catch (Exception e) {
			return false;
		}
		return true;
	}

	// Normalizes the acceleration axes so that z points up/down, y points N/S,
	// and x points E/W
	private static Sample NormalizeAcceleration(Sample s) {
		Transform3D transformer = new Transform3D();
		Vector3f temp = new Vector3f(s.orient[0], s.orient[1], s.orient[2]);
		transformer.setEuler(new Vector3d(temp));
		temp = new Vector3f(s.accel[0], s.accel[1], s.accel[2]);
		transformer.transform(temp);
		s.accel[0] = temp.x;
		s.accel[1] = temp.y;
		s.accel[2] = temp.z - 9.80665f;
		return s;
	}

	/**
	 * Removes samples from data until the start of the data has been shifted
	 * WINDOWSHIFT milliseconds.
	 * 
	 * @param data
	 *            The list of sample data.
	 */
	private static void ShiftWindow(LinkedList<Sample> data) {
		long startTime = data.element().time;

		while (data.size() > 0 && data.element().time - startTime < WINDOWSHIFT) {
			data.remove();
		}
	}

	/**
	 * Creates an ARFFSample from a list of set of raw samples
	 * 
	 * @param data
	 *            A set of raw samples
	 * @return An ARFFSample
	 */
	private static ARFFSample CreateARFFSample(LinkedList<Sample> data, String activity) {
		ARFFSample arff = new ARFFSample(data.element(),activity);
		float[] sums = { 0, 0, 0, 0, 0, 0 };
		float[] products = { 0, 0, 0, 0, 0, 0 };

		// Finds mins,maxs,means
		for (Sample sample : data) {
			for (int i = 0; i < 3; ++i) {
				if (arff.minAcc[i] > sample.accel[i])
					arff.minAcc[i] = sample.accel[i];
				if (arff.maxAcc[i] < sample.accel[i])
					arff.maxAcc[i] = sample.accel[i];
				if (arff.minOri[i] > sample.orient[i])
					arff.minOri[i] = sample.orient[i];
				if (arff.maxOri[i] < sample.orient[i])
					arff.maxOri[i] = sample.orient[i];

				sums[i] += sample.accel[i];
				sums[i + 3] += sample.orient[i];
			}
		}
		for (int i = 0; i < 3; ++i) {
			arff.meanAcc[i] = sums[i] / data.size();
			sums[i] = 0;
			arff.meanOri[i] = sums[i + 3] / data.size();
			sums[i + 3] = 0;
		}

		// Find standard deviations and correlations
		// Use temp to store differences for calculations of correlation
		float[] temp = new float[6];
		for (Sample sample : data) {
			for (int i = 0; i < 3; ++i) {
				temp[i] = (sample.accel[i] - arff.meanAcc[i])
						* (sample.accel[i] - arff.meanAcc[i]);
				sums[i] += temp[i];
				temp[i + 3] += (sample.orient[i] - arff.meanOri[i])
						* (sample.orient[i] - arff.meanOri[i]);
				sums[i + 3] = temp[i + 3];
			}

			products[0] += temp[0] * temp[1];
			products[1] += temp[0] * temp[2];
			products[2] += temp[1] * temp[2];
			products[3] += temp[3] * temp[4];
			products[4] += temp[3] * temp[5];
			products[5] += temp[4] * temp[5];
		}

		// Finishes standard Deviations
		for (int i = 0; i < 3; ++i) {
			arff.stdDevAcc[i] = (float) Math.sqrt(sums[i]);
			arff.stdDevOri[i] = (float) Math.sqrt(sums[i + 3]);
		}

		// Finishes Correlations
		arff.corAcc[0] = products[0] == 0 ? 0 : products[0]
				/ (arff.stdDevAcc[0] * arff.stdDevAcc[1] * data.size());
		arff.corAcc[1] = products[1] == 0 ? 0 : products[1]
				/ (arff.stdDevAcc[0] * arff.stdDevAcc[2] * data.size());
		arff.corAcc[2] = products[2] == 0 ? 0 : products[2]
				/ (arff.stdDevAcc[1] * arff.stdDevAcc[2] * data.size());
		arff.corOri[0] = products[3] == 0 ? 0 : products[3]
				/ (arff.stdDevOri[0] * arff.stdDevOri[1] * data.size());
		arff.corOri[1] = products[4] == 0 ? 0 : products[4]
				/ (arff.stdDevOri[0] * arff.stdDevOri[2] * data.size());
		arff.corOri[2] = products[5] == 0 ? 0 : products[5]
				/ (arff.stdDevOri[1] * arff.stdDevOri[2] * data.size());
		
		//Finds 0-cross
		boolean []above={true,true,true};
		//Initializes above state
		for (int i=0;i<3;++i)
		{
			above[i]=data.element().accel[i]>= arff.meanAcc[i] ? true : false;
		}
		int []crosses={0,0,0};
		//Counts crosses (Adds one when currect above state doesnt match the previous above state
		for (Sample sample : data)
		{
			for (int i=0;i<3;++i)
			{
				if ((sample.accel[i] >= arff.meanAcc[i]) != above[i])
				{
					above[i]=!above[i];
					crosses[i]++;
				}
			}
		}
		for (int i=0;i<3;++i)
			arff.crosses[i]=crosses[i];

		return arff;
	}

	private static void PrintARFF(LinkedList<ARFFSample> elements, String loc)
	{
		LinkedList<String> attributes=ARFFSample.GetAttributes();;
		try
		{
			PrintWriter printer=new PrintWriter(new FileWriter(loc+"/dar.arff"));
			printer.println("@relation DroidActivityRecognition");
			printer.println();
			for (String s:attributes)
			{
				printer.println("@attribute "+ s + " numeric");
			}
			printer.println("@attribute activity {Biking,Climbing,Driving,Lying,Not-on-Person,Running,Sitting,Standing,Walking}");//,CleaningKitchen,Cooking,Medication,Sweeping,WashingHands,WateringPlants}"); 
			printer.println();
			printer.println("@data");
			for (ARFFSample arff:elements)
			{
				printer.println(arff.toString());
			}
			printer.close();
		}
		catch(Exception e)
		{
		}
	}
}
