import java.util.LinkedList;

public class ARFFSample {
	public final float[] meanAcc=new float[3];
	public final float[] minAcc = new float[3];
	public final float[] maxAcc = new float[3];
	public final float[] stdDevAcc = new float[3];
	//0=x,y   1=x,z    2=y,z
	public final float[] corAcc = new float[3];

	public final float[] meanOri=new float[3];
	public final float[] minOri = new float[3];
	public final float[] maxOri = new float[3];
	public final float[] stdDevOri = new float[3];
	//0=x,y   1=x,z    2=y,z
	public final float[] corOri = new float[3];
	
	//0-crosses for each acceleration axis
	public final int[] crosses = new int[3];	
	
	public String activity;

	public ARFFSample(Sample s,String Activity) {	
		for(int i=0;i<3;++i){
			maxAcc[i]=s.accel[i];
			minAcc[i]=s.accel[i];
			maxOri[i]=s.orient[i];
			minOri[i]=s.orient[i];
		}
		activity=Activity;
	}

	@Override
	public String toString() {
		String[] temp = {"","","","","","","","","","",""};
		for (int i = 0; i < 3; ++i) {
			temp[0]+=(meanAcc[i] + ",");
			temp[1]+=(minAcc[i] + ",");
			temp[2]+=(maxAcc[i] + ",");
			temp[3]+=(stdDevAcc[i] + ",");
			temp[4]+=(corAcc[i] + ",");
			temp[5]+=(meanOri[i] + ",");
			temp[6]+=(minOri[i] + ",");
			temp[7]+=(maxOri[i] + ",");
			temp[8]+=(stdDevOri[i] + ",");
			temp[9]+=(corOri[i] + ",");
			temp[10]+=(crosses[i]+",");
		}
		String out="";
		for (int i=0;i<11;++i)
		{
			out+=temp[i];
		}
		out+=activity;
		return out;
	}

	public static LinkedList<String> GetAttributes(){
		LinkedList<String> attributes=new LinkedList<String>();
		String[][] temp=new String[11][3];
		String[] axes={"x","y","z"};
		for (int i=0; i<3;++i){
			temp[0][i]="mean-acc-" + axes[i];
			temp[1][i]="min-acc-" + axes[i];
			temp[2][i]="max-acc-"+axes[i];
			temp[3][i]="std-dev-acc-"+axes[i];
			switch(i){
			case 0:
				temp[4][i]="cor-acc-x-y";
				break;
			case 1:
				temp[4][i]="cor-acc-x-z";
				break;
			case 2:
				temp[4][i]="cor-acc-y-z";
				break;
			}
			temp[5][i]="mean-ori-" + axes[i];
			temp[6][i]="min-ori-" + axes[i];
			temp[7][i]="max-ori-"+axes[i];
			temp[8][i]="std-dev-ori-"+axes[i];
			switch(i){
			case 0:
				temp[9][i]="cor-ori-x-y";
				break;
			case 1:
				temp[9][i]="cor-ori-x-z";
				break;
			case 2:
				temp[9][i]="cor-ori-y-z";
				break;
			}
			temp[10][i]="zero-cross-"+axes[i];
		}
		
		for (String[] s:temp)
		{
			for (String atr:s)
			{
				attributes.add(atr);
			}
		}
		return attributes;
	}
}
