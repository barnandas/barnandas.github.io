package wsu.puck;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Environment;
import android.os.IBinder;
import android.widget.Toast;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;

import java.io.*;
//import java.util.Timer;
//import java.util.TimerTask;

/**
 * Manages collecting sensor data and writing it to a file
 * @author sdernbach
 */
public class ManageSensors extends Service {

	private SensorManager sensorManager;
	private Sensor accelerometer;
	private Sensor orientation;
	private String accelString, orientationString;
	private PrintWriter printWriter;
	
	final SensorEventListener sensorEventListener = new SensorEventListener() {
		
		//Method mandatory for SensorEventListener
		//Doesn't do anything
		public void onAccuracyChanged(Sensor sensor, int accuracy) {
		}

		//Updates the data logs when the sensor values are changed
		public void onSensorChanged(SensorEvent sensorEvent) {
			switch (sensorEvent.sensor.getType()){
			case Sensor.TYPE_ACCELEROMETER:
				accelString=Float.toString(sensorEvent.values[0]) + " " + Float.toString(sensorEvent.values[1]) + " " + Float.toString(sensorEvent.values[2]);
				break;
			case Sensor.TYPE_ORIENTATION:
				orientationString=Float.toString(sensorEvent.values[0]) + " " + Float.toString(sensorEvent.values[1]) + " " + Float.toString(sensorEvent.values[2]);
				break;
			}
			WriteData();
		}
	};
	
		
	@Override
	public void onStart(Intent intent, int command){
		super.onStart(intent, command);
		
		//Prepares sensors
		sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
		accelerometer=sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
		orientation=sensorManager.getDefaultSensor(Sensor.TYPE_ORIENTATION);
		sensorManager.registerListener(sensorEventListener, accelerometer, SensorManager.SENSOR_DELAY_FASTEST);
		sensorManager.registerListener(sensorEventListener, orientation, SensorManager.SENSOR_DELAY_FASTEST);
		
		//Creates the file path
		File dir =new File(Environment.getExternalStorageDirectory().getAbsolutePath()+ "/data/puck/" + intent.getStringExtra("User"));
		dir.mkdirs();
		File f=new File(dir + "/" + intent.getStringExtra("Task") + ".raw");
		//Create the raw data file if it doesn't exist
		if (!f.exists()) {
			try {
				f.createNewFile();
			} 
			catch (IOException e) {Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();}
		}
		
		//Open the raw data file in append mode
		try {
			printWriter=new PrintWriter(new FileWriter(f,true),true);
		} 
		catch (IOException e) {
			Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
		}
		
		//Writes a blank line to separate this instance from the last one
		printWriter.println(); 
		printWriter.println(intent.getStringExtra("Location"));
	}
	
	@Override
	public void onDestroy() {
		super.onDestroy();
		sensorManager.unregisterListener(sensorEventListener);
		printWriter.close();
	}
	
	//Writes a line to the raw data file
	private void WriteData(){
		printWriter.println(System.currentTimeMillis() + " " + accelString + " " + orientationString);
	}
	
	//Must have this function
	@Override
	public IBinder onBind(Intent intent) {
		return null;
	}

	
}