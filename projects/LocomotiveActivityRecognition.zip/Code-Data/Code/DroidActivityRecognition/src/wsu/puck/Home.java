package wsu.puck;

import wsu.puck.R;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

/**
 * Manages the entry screen for the app. Controls creating new activities based on users choices.
 * @author sdernbach
 */
public class Home extends Activity implements OnClickListener {

	Button buttonGather, buttonTrain, buttonTest;

	// Called when the activity is first created.
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		buttonGather = (Button) findViewById(R.id.buttonGather);
		buttonTrain = (Button) findViewById(R.id.buttonTrain);
		buttonTest = (Button) findViewById(R.id.buttonTest);

		buttonGather.setOnClickListener(this);
		buttonTrain.setOnClickListener(this);
		buttonTest.setOnClickListener(this);
	}

	/**
	 * Called when a button on the home screen is clicked.
	 * Each button spawns a new activity that takes control.
	 */
	public void onClick(View src) {
		switch (src.getId()) {
		case R.id.buttonGather:
			startActivity(new Intent(this,Gather.class));
			break;
		case R.id.buttonTest:
			startActivity(new Intent(this,Test.class));
			break;
		default:
		break;
		}
	}

}