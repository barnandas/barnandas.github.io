package wsu.puck;

import wsu.puck.R;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Controls the interface and backend for collecting data.
 * 
 * @author sdernbach
 */
public class Gather extends Activity implements OnClickListener {

	Button buttonStart, buttonStop;
	Spinner spinnerActivities;
	Spinner spinnerLocations;
	TextView statusText;
	EditText editText;
	boolean serviceRunning;
	Bundle bundle;
	int actSpinnerPos, locSpinnerPos;
	Intent sensors;

	// Called when the activity is first created.
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.gather);

		serviceRunning = false;
		bundle = new Bundle();
		sensors = new Intent(this, ManageSensors.class);
		statusText=(TextView)findViewById(R.id.statusText);
		editText=(EditText)findViewById(R.id.editUserId);

		// Sets up buttons
		buttonStart = (Button) findViewById(R.id.buttonStart);
		buttonStop = (Button) findViewById(R.id.buttonStop);

		buttonStart.setOnClickListener(this);
		buttonStop.setOnClickListener(this);

		// Sets up spinners
		// Loads spinner choices from strings.xml "activities_array" and "locations_array"
		spinnerActivities = (Spinner) findViewById(R.id.spinnerActivities);
		ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
				this, R.array.activities_array,
				android.R.layout.simple_spinner_item);
		adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		spinnerActivities.setAdapter(adapter);

		spinnerLocations = (Spinner) findViewById(R.id.spinnerLocations);
		ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(
				this, R.array.locations_array,
				android.R.layout.simple_spinner_item);
		adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		spinnerLocations.setAdapter(adapter2);
	}

	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.buttonStart:
			//Starts the data collection service if it isn't already running
			if (!serviceRunning) {
				actSpinnerPos = spinnerActivities.getSelectedItemPosition();
				locSpinnerPos = spinnerLocations.getSelectedItemPosition();
				sensors.putExtra("Task", (String) spinnerActivities
						.getItemAtPosition(actSpinnerPos));
				sensors.putExtra("Location", (String) spinnerLocations
						.getItemAtPosition(locSpinnerPos));
				sensors.putExtra("User",editText.getText().toString());
				try {
					if (startService(sensors) == null) {
						Toast.makeText(this, "Error starting service",
								Toast.LENGTH_SHORT).show();
						finish();
					}
					Toast.makeText(this, "Data Collection Started",Toast.LENGTH_SHORT).show();
					statusText.setText("Data Collection Started.");
					
				} catch (Exception e) {
					Log.d(null, e.getMessage());
				}
				;
				serviceRunning = true;
				// Toast.makeText(this, "Data Collection Starting",
				// Toast.LENGTH_SHORT).show();
			} else {
				Toast.makeText(this, "Data Collection Already Running",
						Toast.LENGTH_SHORT).show();
			}
			break;
		//Stops the data collection service
		case R.id.buttonStop:
			stopService(sensors);
			serviceRunning = false;
			Toast.makeText(this, "Data Collection Stopped", Toast.LENGTH_SHORT).show();
			statusText.setText("Data Collection Stopped.");
			break;
		}
	}
}