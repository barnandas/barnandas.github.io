package wsu.puck;
public class Sample{
	long time;
	public final float [] accel=new float[3];
	public final float [] orient=new float[3];
	public String activity;
	
	public Sample(long t,float aX, float aY, float aZ, float oX, float oY, float oZ)
	{
		time=t;
		accel[0]=aX;
		accel[1]=aY;
		accel[2]=aZ;
		orient[0]=oX;
		orient[1]=oY;
		orient[2]=oZ;
	}
	
	public static Sample Parse(String s)
	{
		if (s==null) return null;
		String[] parts=s.split(" ");
		if (parts.length<6)
			return null;
		
		long t=Long.parseLong(parts[0]);
		float accX=Float.parseFloat(parts[1]);
		float accY=Float.parseFloat(parts[2]);
		float accZ=Float.parseFloat(parts[3]);
		//Note: Orientation does not come in the same order as acceleration so it is fixed here
		float oriX=Float.parseFloat(parts[5]);
		float oriY=-Float.parseFloat(parts[6]);
		float oriZ=Float.parseFloat(parts[4]);
		
		return new Sample(t,accX,accY,accZ,oriX,oriY,oriZ);	
	}
}