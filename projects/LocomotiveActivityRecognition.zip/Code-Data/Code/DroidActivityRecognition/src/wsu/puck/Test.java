package wsu.puck;

import java.util.LinkedList;
import java.io.*;

import android.app.Activity;
import android.content.Context;
import android.content.res.AssetManager;
import android.widget.TextView;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;

import android.os.PowerManager;
import android.os.PowerManager.WakeLock;

import weka.classifiers.bayes.NaiveBayes;
import weka.core.Instance;
import weka.core.Instances;

/**
 * Manages collecting sensor data and writing it to a file
 * @author sdernbach
 */
public class Test extends Activity {

	private SensorManager sensorManager;
	private Sensor accelerometer;
	private Sensor orientation;
	private String accelString, orientationString;
	
	private LinkedList<Sample> oldList;
	private LinkedList<Sample> newList;
	
	private int oldCount;
	private float []oldMin;
	private float []oldTotal;
	private float []oldMax;
	
	private int newCount;
	private float []newMin;
	private float []newTotal;
	private float []newMax;
	
	private NaiveBayes rf;
	private Instance instance;
	private Instances instances;
	
	private PowerManager pm;
	private WakeLock wl;
	
	private TextView activityView;
	private TextView statusView;
	
	private double updates=0;
	
	private double c;
	
	@Override
	public void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.test);
		statusView=(TextView) findViewById(R.id.statusView);
		activityView=(TextView)findViewById(R.id.activityView);
		
		pm = (PowerManager) getSystemService(Context.POWER_SERVICE); 
		
		wl = pm.newWakeLock
		     (PowerManager.SCREEN_DIM_WAKE_LOCK, "My Tag"); 

		wl.acquire(); 
		//setContentView(R.layout.test);
		
		//Initializes features
		oldCount=0;
		newCount=0;
		oldMin=new float[6];
		oldTotal=new float[6];
		oldMax=new float[6];
		newMin=new float[6];
		newTotal=new float[6];
		newMax=new float[6];
		newList=new LinkedList<Sample>();
		oldList=new LinkedList<Sample>();
		
		//Sets up weka
		AssetManager a=getAssets();
		InputStream is;
		try {
			//is=new FileInputStream(Environment.getExternalStorageDirectory().getAbsolutePath()+ "/data/puck/tree.model");
			is= a.open("models/tree.model");
			ObjectInputStream objectIS = new ObjectInputStream(is);
			rf = (NaiveBayes) objectIS.readObject();
			
			
			statusView.setText("Building Instances");
			instances = new Instances((Reader) new InputStreamReader(a.open("models/af.arff")));
			statusView.setText("Ready");
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} 		
		instances.setClassIndex(instances.numAttributes() -1);
		instance=new Instance(instances.numAttributes());
		instance.setDataset(instances);
		
		//Prepares sensors
		sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
		accelerometer=sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
		orientation=sensorManager.getDefaultSensor(Sensor.TYPE_ORIENTATION);
		sensorManager.registerListener(sensorEventListener, accelerometer, SensorManager.SENSOR_DELAY_FASTEST);
		sensorManager.registerListener(sensorEventListener, orientation, SensorManager.SENSOR_DELAY_FASTEST);
	}
	
	final SensorEventListener sensorEventListener = new SensorEventListener() {
		
		//Method mandatory for SensorEventListener
		//Doesn't do anything
		public void onAccuracyChanged(Sensor sensor, int accuracy) {
		}

		//Updates the data logs when the sensor values are changed
		public void onSensorChanged(SensorEvent sensorEvent) {
			switch (sensorEvent.sensor.getType()){
			case Sensor.TYPE_ACCELEROMETER:
				accelString=Float.toString(sensorEvent.values[0]) + " " + Float.toString(sensorEvent.values[1]) + " " + Float.toString(sensorEvent.values[2]);
				break;
			case Sensor.TYPE_ORIENTATION:
				orientationString=Float.toString(sensorEvent.values[0]) + " " + Float.toString(sensorEvent.values[1]) + " " + Float.toString(sensorEvent.values[2]);
				break;
			}
			DealData();
		}
	};
	
	@Override
	public void onDestroy() {
		super.onDestroy();
		sensorManager.unregisterListener(sensorEventListener);
		wl.release();
	}
	
	//Writes a line to the raw data file
	private void DealData(){
		Sample s=Sample.Parse(Long.toString(System.currentTimeMillis()) + " " + accelString + " " + orientationString);
		if (s==null)
			return;
		
		newList.add(s);
		
		//Calculate min/max/mean
		for (int i=0;i<3;++i)
		{
			if (newCount==0)
			{
				newMin[i]=s.accel[i];
				newMin[i+3]=s.orient[i];
				newMax[i]=s.accel[i];
				newMax[i+3]=s.orient[i];
			}
			else
			{
				if (s.accel[i] < newMin[i])
					newMin[i]=s.accel[i];
				if (s.orient[i] < newMin[i+3])
					newMin[i+3]=s.orient[i];
				if (s.accel[i] > newMax[i])
					newMax[i]=s.accel[i];
				if (s.orient[i] > newMax[i+3])
					newMax[i+3]=s.orient[i];
			}
			newTotal[i]+=s.accel[i];
			newTotal[i+3]+=s.orient[i];
		}
		++newCount;
		
		//Takes care of program startup
		if (oldList.size()==0)
		{
			if (newList.getLast().time - newList.element().time < 4000)
				return;
			else
			{
				Swap();
				return;
			}
		}
		
		//If 4 seconds have passed
		//Find final features and reset temporaries
		if (s.time - oldList.element().time > 4000)
		{
			FindFinals();
			//Discover activity
			Swap();
		}
	}	
	
	//Swaps the oldList and the newList
	private void Swap()
	{
		oldList=(LinkedList<Sample>) newList.clone();
		newList.clear();
		
		oldMin=newMin.clone();
		oldMax=newMax.clone();
		oldTotal=newTotal.clone();
		oldCount=newCount;
		
		for (int i=0;i<6;++i)
			newTotal[i]=0;
		newCount=0;
	}
	
	private void FindFinals()
	{
		//Initialize
		oldList.addAll(newList);
		int count=oldCount+newCount;
		float []minAcc=new float[3];
		float []maxAcc=new float[3];
		float []meanAcc=new float[3];
		float []minOri=new float[3];
		float []maxOri=new float[3];
		float []meanOri=new float[3];
		float []stdDevAcc=new float[3];
		float []stdDevOri=new float[3];
		float []corAcc=new float[3];
		float []corOri=new float[3];
		int []crosses={0,0,0};
		
		//Find min max and mean
		for (int i=0;i<3;++i)
		{
			minAcc[i]= oldMin[i] < newMin[i] ? oldMin[i] : newMin[i];
			maxAcc[i]= oldMax[i] > newMax[i] ? oldMax[i] : newMax[i];
			meanAcc[i]=(oldTotal[i]+newTotal[i])/(count);
			
			minOri[i]= oldMin[i+3] < newMin[i+3] ? oldMin[i+3] : newMin[i+3];
			maxOri[i]= oldMax[i+3] > newMax[i+3] ? oldMax[i+3] : newMax[i+3];
			meanOri[i]=(oldTotal[i+3]+newTotal[i+3])/(count);
		}
		
		// Find standard deviations and correlations
		// Use temp to store differences for calculations of correlation
		float[] temp = new float[6];
		float[] sums = {0,0,0,0,0,0};
		float[] products= {0,0,0,0,0,0};
		for (Sample sample : oldList) {
			for (int i = 0; i < 3; ++i) {
				temp[i] = (sample.accel[i] - meanAcc[i])
						* (sample.accel[i] - meanAcc[i]);
				sums[i] += temp[i];
				temp[i + 3] += (sample.orient[i] - meanOri[i])
						* (sample.orient[i] - meanOri[i]);
				sums[i + 3] = temp[i + 3];
			}

			products[0] += temp[0] * temp[1];
			products[1] += temp[0] * temp[2];
			products[2] += temp[1] * temp[2];
			products[3] += temp[3] * temp[4];
			products[4] += temp[3] * temp[5];
			products[5] += temp[4] * temp[5];
		}
		// Finishes standard Deviations
		for (int i = 0; i < 3; ++i) {
			stdDevAcc[i] = (float) Math.sqrt(sums[i]);
			stdDevOri[i] = (float) Math.sqrt(sums[i + 3]);
		}
		// Finishes Correlations
		corAcc[0] = products[0] == 0 ? 0 : products[0]
				/ (stdDevAcc[0] * stdDevAcc[1] * count);
		corAcc[1] = products[1] == 0 ? 0 : products[1]
				/ (stdDevAcc[0] * stdDevAcc[2] * count);
		corAcc[2] = products[2] == 0 ? 0 : products[2]
				/ (stdDevAcc[1] * stdDevAcc[2] * count);
		corOri[0] = products[3] == 0 ? 0 : products[3]
				/ (stdDevOri[0] * stdDevOri[1] * count);
		corOri[1] = products[4] == 0 ? 0 : products[4]
				/ (stdDevOri[0] * stdDevOri[2] * count);
		corOri[2] = products[5] == 0 ? 0 : products[5]
				/ (stdDevOri[1] * stdDevOri[2] * count);
		
		//Finds 0-cross
		boolean []above={true,true,true};
		//Initializes above state
		for (int i=0;i<3;++i)
		{
			above[i]=oldList.element().accel[i]>= meanAcc[i] ? true : false;
		}
		//Counts crosses (Adds one when currect above state doesnt match the previous above state
		for (Sample sample : oldList)
		{
			for (int i=0;i<3;++i)
			{
				if ((sample.accel[i] >= meanAcc[i]) != above[i])
				{
					above[i]=!above[i];
					crosses[i]++;
				}
			}
		}
		
		//Add everything to an instance
		for (int i=0;i<3;++i)
		{
			instance.setValue(i, meanAcc[i]);
			instance.setValue(i+3, minAcc[i]);
			instance.setValue(i+6, maxAcc[i]);
			instance.setValue(i+9, stdDevAcc[i]);
			instance.setValue(i+12, corAcc[i]);
			instance.setValue(i+15, meanOri[i]);
			instance.setValue(i+18, minOri[i]);
			instance.setValue(i+21, maxOri[i]);
			instance.setValue(i+24, stdDevOri[i]);
			instance.setValue(i+27, crosses[i]);
			instance.setValue(i+30,corOri[i]);
		}
		 
		try {
			c=rf.classifyInstance(instance);
			activityView.setText(instances.classAttribute().value((int) c));
			++updates;
			statusView.setText("Updated: " + updates);
		} catch (Exception e) {
			// TODO Auto-generated catch block
		}
	}
}