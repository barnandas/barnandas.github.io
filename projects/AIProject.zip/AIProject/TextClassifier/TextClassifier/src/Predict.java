import java.lang.*;
import java.io.*;
import java.util.*;

public class Predict {
	public static void prediction() throws IOException{
		for (int i=0; i<20; i++){
			Global.classProperties[i][0] = (float)(Global.classTF[i][0] + Global.classTF[i][1])/(float)(Global.classTF[i][0]+Global.classTF[i][1]+Global.classTF[i][2]+Global.classTF[i][3]);	//Accuracy
			Global.classProperties[i][1] = (float)Global.classTF[i][0]/(float)(Global.classTF[i][0] + Global.classTF[i][2]);	//Precision 
			Global.classProperties[i][2] = (float)Global.classTF[i][0]/(float)(Global.classTF[i][0] + Global.classTF[i][3]);	//Recall
			Global.classProperties[i][3] = (2*Global.classProperties[i][1]*Global.classProperties[i][2]) / (Global.classProperties[i][1] + Global.classProperties[i][2]);	//F1 Measure
		}
		
		String className[] = {"alt.atheism","comp.graphics","comp.os.ms-windows.misc","comp.sys.ibm.pc.hardware","comp.sys.mac.hardware",
				"comp.windows.x","misc.forsale","rec.autos","rec.motorcycles","rec.sport.baseball","rec.sport.hochey","sci.crypt",
				"sci.electronics","sci.med","sci.space","soc.religion.christian","talk.politics.guns","talk.politics.mideast",
				"talk.politics.misc","talk.religion.misc"};
		
		
		
		System.out.println("TP\tTN\tFP\tFN\tAccuracy\tPrecision\tRecall\tF1 Measure");
		System.out.println("----------------------------------------------------------------------------------------------");
		System.out.println();
		
		for (int i=0; i<20; i++){
			for (int j=0; j<4; j++){
				System.out.print(Global.classTF[i][j]+"\t");
				}
			for (int j=0; j<4; j++){
				System.out.print(Global.classProperties[i][j]+"\t");
				}
			System.out.println();
		}

	}
}
