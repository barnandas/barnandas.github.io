/*
 * 				Author: Barnan Das
 * 				Project: Development of a Text Classifier using Naive Bayes Classifier
 * 
 */

import java.lang.*;
import java.io.*;
import java.util.*;

public class TextClassifier {
	
	public static void main(String[] args) throws IOException {
	
// Take a note of the training start time.
		System.out.println("Training Starts...\n");
		long start = System.currentTimeMillis();
		
		Train.training();
		System.out.println("Training ends.\n");
		
		System.out.println("Testing starts...");
		Test.testing();
		System.out.println("Testing ends.");
		
		long end = System.currentTimeMillis();
		System.out.println("Execution time: "+ (float)((end - start)/1000.0)+" seconds\n");
		
		Predict.prediction();
		
	}
}