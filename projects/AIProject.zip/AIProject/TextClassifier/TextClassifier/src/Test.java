/*
 * 				Author: Barnan Das
 * 				Project: Development of a Text Classifier using Naive Bayes Classifier
 * 
 */

import java.lang.*;
import java.io.*;
import java.util.*;

public class Test {
	public static void testing() throws IOException{
		
		
	// Initialize the array for determining TP, TN, FP, FN
		for (int i=0; i<20; i++){
			for (int j=0; j<4; j++){
				Global.classTF[i][j]=0;
			}
		}
		
	// Initialize the array for determining Accuracy, Precision, Recall, F1 Measure
		for (int i=0; i<20; i++){
			for (int j=0; j<4; j++){
				Global.classProperties[i][j]=(float)0.0;
			}
		}	
		
		File folder = new File(Global.testPath);
		String[] level1 = folder.list();
	
	// Reads files from each sub folder of the testing corpus
		for (int i=0; i<level1.length; i++){
			File subFolder = new File(Global.testPath + "/" + level1[i]);
			String[] level2 = subFolder.list();
	
			
			Global.docsTest[i]=2/*level2.length*/; //HAVE TO BE CHANGED
			Global.exampleTest += Global.docsTest[i] ;
					
		// Reading from each file
			for (int j= 0; j<2/*level2.length*/; j++){	//HAVE TO BE CHANGED
								
				BufferedReader in = new BufferedReader(new FileReader(Global.testPath+ "/" +level1[i] +"/" + level2[j]));
				
				String str = new String();
				String fileContent = new String();
								
			// Reading the content of a file into fileContent	    
		    	while ((str = in.readLine()) != null) {
		    	  	fileContent = fileContent + str + '\n';
		        }

		    	int max = calculate(fileContent);
		    	
	//	    	System.out.println("Actual: " + i + "\tPredicted: "+max);
		    	if (max == i){
		    		Global.classTF[i][0]++;	//Increment TP for class i
		    		for (int classItr=0; classItr<20; classItr++){	//Increment TN for all other classes
		    			if (classItr==i)
		    				{continue;}
		    			Global.classTF[classItr][1]++;
		    		}
		    	}
		    	else{
		    		Global.classTF[i][3]++;	//Increment FN for class i
		    		Global.classTF[max][2]++;	//Increment FP for class i
		    		for (int classItr=0; classItr<20; classItr++){	//Increment TN for all other classes
		    			if (classItr==i || classItr==max)
		    				{continue;}
		    			Global.classTF[classItr][1]++;
		    		}
		    	}
		    	
		    	
		    	
		    	in.close();
		    	
			}
			
			
		}
	}
	
	public static int calculate(String getFileContent) throws IOException{
		
	// Initializing the argMax array	
		for (int i=0; i<20; i++){
			Global.argMax[i] = Global.probTopic[i];
		}

		
		String tokWord = new String();
		
	// Tokenizes the file	
    	for (int i=0; i<20; i++){
    		StringTokenizer token = new StringTokenizer(getFileContent," \t\n\r\f1234567890~!@#$%^&*()-_+={}[]:;\"'<,>.?/|\\");
        	
    		while (token.hasMoreTokens()){
    			tokWord = (token.nextToken()).toLowerCase();
    		
    			// Checks if the token is a stop word	
    			short match =0;
    			for (int sWordItr=0; sWordItr<571; sWordItr++){
    				if (tokWord.compareTo(Global.sWords[sWordItr])==0)
    					{match=1;break;}
    			}
    			String stem = Stemmer.stemming(tokWord);
    			if (match==0){
    			// Checks if the word is in the topic list	
    				
    				Vocab list = new Vocab(); 
    				NodeProb x = new NodeProb();
    			    			
    				list = Global.probWord[i];
    				
    				for (int j=0; j<list.probList.size(); j++){
    					x = list.probList.get(j);
    					if (stem.compareTo(x.word)==0){
    						Global.argMax[i] *= x.p;
    						break;
    					}
    					else
    						{continue;}
    				}      			
    			}
    			else
    				{continue;}
    		}
		}
    	
    	// Finding the Maximum value in argMax array
    	float max = Global.argMax[0];
    	int maxIndex = 0;
    	for (int i=0; i<20; i++){
    		if (max < Global.argMax[i]){
    			max = Global.argMax[i];
    			maxIndex = i;
    		}
    	}
    	return(maxIndex);
		
	}
	
}
