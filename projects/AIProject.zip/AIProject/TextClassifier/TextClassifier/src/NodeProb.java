public class NodeProb {
	String word = new String();
	float p;
	
	public NodeProb(){}
		
	public NodeProb(String string, float i) {
		word = string;
		p = i;
	}
		
}
