import java.lang.*;
import java.io.*;
import java.util.*;

public class Stemmer {
	public static String stemming(String str) throws IOException{
		String stemSuffix[][] = new String[30][2];
		
		BufferedReader stem = new BufferedReader(new FileReader(Global.stemmerPath));
		String s = new String();
		String line = new String();
		int count=0;
		
		while ((line = stem.readLine()) != null) {
			StringTokenizer token = new StringTokenizer(line,",");
	    	while (token.hasMoreTokens()){
	    		stemSuffix[count][0]=token.nextToken();
	    		stemSuffix[count][1]=token.nextToken();
			}
	    	count++;
		}
		
		for (int i=0; i<30; i++){
			if (str.endsWith(stemSuffix[i][0].substring(1))){
				s = (str.substring(0,(str.length()-stemSuffix[i][0].length())+1)).concat(stemSuffix[i][1].substring(1));
				break;
			}
			else 
				{s = str;}
			
		}
		stem.close();
		return s;
	}
}
