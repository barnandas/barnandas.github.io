public class Node {
	String word = new String();
	int freq;
	
	public Node(){}
		
	public Node(String string, int i) {
		word = string;
		freq = i;
	}
		
}
