import java.lang.*;
import java.io.*;
import java.util.*;

public class Vocab {
	LinkedList<NodeProb> probList = new LinkedList<NodeProb>(); 
	
}
