import java.lang.*;
import java.io.*;
import java.util.*;

public class Global{
	
	static String trainPath = "C:/Resources/20news-bydate-train";
	static String testPath = "C:/Resources/20news-bydate-test";
	static String swPath = "C:/Resources/Stopwords.txt";
	static String vocabPath = "C:/Resources/vocab"; 
	static String stemmerPath = "C:/Resources/StemmerSuffix.txt";
	
	// Stores the stop words
	static String sWords[] = new String[571];
	
	// Variables used for training purpose
	static int docsTrain[] = new int[20];
	static int exampleTrain = 0;
	static int sumFreq[] = new int[20];	// Summation of frequencies of all the words in a topic

	// Variables used for testing purpose
	static int docsTest[] = new int[20];
	static int exampleTest = 0;
	
	// Variables used for the prediction purpose
	
	static float probTopic[] = new float[20];
	static Vocab probWord[] = new Vocab[20];
	
//	static String probWord[][][] = new String[20][4000][2];
	static float argMax[] = new float[20];
	
	// Variables used for the prediction purpose
	static int classTF[][] = new int[20][4]; //1st dimension 20 is for #classes, 2nd dimension 4 for TP, TN, FP, FN in order
	static float classProperties[][] = new float[20][4]; //1st dimension 20 is for #classes, 2nd dimension 4 for Accuracy, Prediction, Recall, F1 Measure in order
	
	
}
