/*
 * 				Author: Barnan Das
 * 				Project: Development of a Text Classifier using Naive Bayes Classifier
 * 
 */

import java.lang.*;
import java.io.*;
import java.util.*;

public class Train {
	public static void training() throws IOException{
//------------MAKING THE STOPWORDS ARRAY---------------------------------------------------------------------------------------------			
		BufferedReader stopWords = new BufferedReader(new FileReader(Global.swPath));
		String s = new String();
				
		short count=0;
		while ((s = stopWords.readLine())!= null){
			Global.sWords[count++]=s;
		}
		
		stopWords.close();
//------------------------------------------------------------------------------------------------------------------------------------
		File folder = new File(Global.trainPath);
		String[] level1 = folder.list();
		
	// Reads files from each sub folder of the training corpus
		for (int i=0; i<level1.length; i++){
			
			System.out.println("Training on " + level1[i]);
			
		// The vocabulary linked list	
			LinkedList<Node> vocabulary = new LinkedList<Node>();
			Node x = new Node();
			
			BufferedWriter out = new BufferedWriter(new FileWriter(Global.vocabPath+"/vocab-"+level1[i]+".txt"));
			
			File subFolder = new File(Global.trainPath+ "/" + level1[i]);
			String[] level2 = subFolder.list();
			
			Global.docsTrain[i]=5/*level2.length*/; //HAVE TO BE CHANGED
			Global.exampleTrain += Global.docsTrain[i] ;
			
		// Reading from each file
			for (int j= 0; j<5/*level2.length*/; j++){	//HAVE TO BE CHANGED
								
				BufferedReader in = new BufferedReader(new FileReader(Global.trainPath+"/"+level1[i]+"/"+level2[j]));
				
				String str = new String();
				String fileContent = new String();
				String tokWord = new String();
				
			// Reading the content of a file into fileContent	    
		    	while ((str = in.readLine()) != null) {
		    	  	fileContent = fileContent + str + '\n';
		        }

		    // Tokenizes the file	
		    	StringTokenizer token = new StringTokenizer(fileContent," \t\n\r\f1234567890~!@#$%^&*()-_+={}[]:;\"'<,>.?/|\\");
		    	
		    	while (token.hasMoreTokens()){
		    		
		    		tokWord = (token.nextToken()).toLowerCase();
		    		
		    	// Checks if the token is a stop word	
		    		short match =0;
		    		for (int sWordItr=0; sWordItr<571; sWordItr++){
		    			if (tokWord.compareTo(Global.sWords[sWordItr])==0)
		    				{match=1;break;}
		    		}
		    		String stem = Stemmer.stemming(tokWord);
		    		if (match==0){
		    		// Checks if the stem word is already in the vocabulary list 	
		    			short match2=0;
		    			for (int llCounter=0;llCounter<vocabulary.size();llCounter++){
		    				x = vocabulary.get(llCounter);
		    				if (stem.compareTo(x.word)==0)
		    					{x.freq++; match2=1; break;}
		    			}
		    			
		    			if (match2==0)
		    				{vocabulary.add(new Node(stem,1));}		    			
		    		}
		    		else
		    			{continue;}
		    	}
		   		    	
		    	in.close();
		    	
			}
		
		// Summation of frequencies of all the words	
			
			for (int k=0; k<vocabulary.size(); k++){
				x = vocabulary.get(k);
				Global.sumFreq[i] += x.freq;
			}
			
		// Assigning values to probWords array defined in class Global
			Vocab list = new Vocab();
			
			for (int k=0; k<vocabulary.size(); k++){
				x = vocabulary.get(k);
				NodeProb y = new NodeProb();
				y.word = x.word;
				y.p = (float)(x.freq + 1)/(float)(Global.sumFreq[i]);
				list.probList.add(y);
			}
			
			Global.probWord[i] = list;

		// Writes the vocabulary linked list to a file 	
	    	for (int fileItr=0; fileItr<vocabulary.size(); fileItr++){
	    		x = vocabulary.get(fileItr);
	    		out.write(x.word + " , " + x.freq);
	    		out.newLine();
	    	}
		
			out.close();	
					
		}
		
		for (int i=0; i<20; i++){
			Global.probTopic[i] = (float)Global.docsTrain[i]/(float)Global.exampleTrain;
		}
	}
}
